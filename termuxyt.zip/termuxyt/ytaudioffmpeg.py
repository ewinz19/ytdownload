#!/usr/bin/env python3
import sys
import os
import re
import subprocess
from pytubefix import YouTube

# Configuration
ALLOWED_CLIENTS = {
    'WEB', 'WEB_EMBED', 'WEB_MUSIC', 'WEB_CREATOR', 'WEB_SAFARI',
    'ANDROID', 'ANDROID_MUSIC', 'ANDROID_CREATOR', 'ANDROID_VR',
    'ANDROID_PRODUCER', 'ANDROID_TESTSUITE', 'IOS', 'IOS_MUSIC',
    'IOS_CREATOR', 'MWEB', 'TV', 'TV_EMBED', 'MEDIA_CONNECT'
}
OUTPUT_FOLDER = "/data/data/com.termux/files/home/storage/downloads/AA-yt/mp3"
DEFAULT_CLIENT = "WEB"

def sanitize_filename(title):
    """Clean filename from invalid characters"""
    return re.sub(r'[\\/*?:"<>|]', "", title).strip()

def is_client_allowed(client):
    """Check if client is allowed"""
    return client in ALLOWED_CLIENTS

def convert_to_mp3(input_path, output_path):
    """Convert audio file to MP3 using ffmpeg"""
    try:
        subprocess.run([
            'ffmpeg',
            '-i', input_path,
            '-q:a', '0',
            '-map', 'a',
            '-loglevel', 'error',  # Suppress ffmpeg noise
            '-y',  # Overwrite if exists
            output_path
        ], check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Gagal mengkonversi ke MP3: {e}")
        return False
    except FileNotFoundError:
        print("Error: ffmpeg tidak ditemukan. Pastikan ffmpeg terinstall.")
        return False

def download_audio(link):
    """Download and convert YouTube audio to MP3"""
    try:
        yt = YouTube(link)
        audio_stream = yt.streams.filter(only_audio=True).first()
        
        if not audio_stream:
            print("Error: Video tidak memiliki audio stream")
            return False

        # Prepare download
        safe_title = sanitize_filename(yt.title)
        os.makedirs(OUTPUT_FOLDER, exist_ok=True)
        temp_path = os.path.join(OUTPUT_FOLDER, f"temp_{safe_title}.mp4")
        final_path = os.path.join(OUTPUT_FOLDER, f"{safe_title}.mp3")

        # Download audio
        print(f"Mendownload: {yt.title}")
        audio_stream.download(output_path=OUTPUT_FOLDER, filename=os.path.basename(temp_path))

        # Convert to MP3
        if convert_to_mp3(temp_path, final_path):
            os.remove(temp_path)  # Clean up temp file
            print(f"Berhasil disimpan di: {final_path}")
            return True
        
        return False

    except Exception as e:
        print(f"Error saat memproses {link}: {str(e)}")
        return False

def main():
    if len(sys.argv) != 2:
        print("Penggunaan: python script.py <URL YouTube>")
        sys.exit(1)

    if not is_client_allowed(DEFAULT_CLIENT):
        print(f"Error: Klien {DEFAULT_CLIENT} tidak diizinkan")
        sys.exit(1)

    youtube_url = sys.argv[1]
    download_audio(youtube_url)

    if sys.stdout.isatty():  # Only wait for input if run interactively
        input("Tekan Enter untuk keluar...")

if __name__ == "__main__":
    main()