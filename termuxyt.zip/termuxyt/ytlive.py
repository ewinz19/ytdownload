#!/data/data/com.termux/files/usr/bin/python
import sys
import yt_dlp
import os
from datetime import datetime

# Config path
OUTPUT_DIR = "/storage/emulated/0/Download/AA-yt"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def get_youtube_m3u8(url):
    try:
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
            'forceurl': True,
            'format': 'best',
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if 'url' in info:
                return info['url']
            elif 'entries' in info:
                return info['entries'][0]['url']
            else:
                raise Exception("Failed to extract M3U8 URL")

    except Exception as e:
        print(f"Error: {str(e)}")
        return None

def save_m3u_playlist(url, m3u8_url):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"youtube_live_{timestamp}.m3u"
    filepath = os.path.join(OUTPUT_DIR, filename)

    with open(filepath, 'w') as f:
        f.write("#EXTM3U\n")
        f.write("#EXTINF:-1,YouTube Live\n")
        f.write(f"{m3u8_url}|User-Agent=Mozilla/5.0\n")

    return filepath

def main():
    if len(sys.argv) < 2:
        print("Usage: python yt2iptv.py <youtube_url>")
        return

    youtube_url = sys.argv[1]
    m3u8_url = get_youtube_m3u8(youtube_url)

    if m3u8_url:
        saved_path = save_m3u_playlist(youtube_url, m3u8_url)
        print(f"Playlist saved to: {saved_path}")
    else:
        print("Failed to create playlist")

if __name__ == "__main__":
    main()