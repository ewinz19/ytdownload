#!/usr/bin/env python3

import sys
import os
import re
from pytubefix import YouTube
import shutil

def sanitize_filename(filename):
    """Membersihkan nama file dari karakter tidak valid"""
    # Hapus karakter tidak aman untuk nama file
    cleaned = re.sub(r'[\\/*?:"<>|]', "", filename)
    # Ganti multiple spaces dengan single space
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned

def Download(link):
    try:
        youtubeObject = YouTube(link)
        video = youtubeObject.streams.get_highest_resolution()
        
        # Dapatkan judul video dan bersihkan
        original_title = youtubeObject.title
        safe_title = sanitize_filename(original_title)
        
        # Tentukan folder tujuan
        destination_folder = "/data/data/com.termux/files/home/storage/downloads/AA-yt/video"
        os.makedirs(destination_folder, exist_ok=True)

        # Download dengan nama file yang sudah dibersihkan
        file_path = video.download(output_path=destination_folder, filename=f"{safe_title}.mp4")
        
        print(f"Download berhasil disimpan di: {file_path}")
        
    except Exception as e:
        print(f"Terjadi kesalahan saat mendownload {link}: {str(e)}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Penggunaan: python script.py <URL video YouTube>")
        sys.exit(1)
    
    link = sys.argv[1]
    Download(link)