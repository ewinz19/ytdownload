import os
import sys
from yt_dlp import YoutubeDL

def download_instagram_video(url):
    try:
        # Tentukan folder tujuan
        destination_folder = "/data/data/com.termux/files/home/storage/downloads/AA-ig/video/"
        
        # Buat folder jika belum ada
        if not os.path.exists(destination_folder):
            os.makedirs(destination_folder)

        # Konfigurasi yt-dlp
        ydl_opts = {
            'outtmpl': os.path.join(destination_folder, '%(title)s.%(ext)s'),  # Simpan video dengan judul sebagai nama file
            'format': 'best',  # Unduh format terbaik
            'quiet': True,  # Nonaktifkan output verbose
        }

        # Unduh video
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        print("Download video Instagram selesai dengan sukses!")
    except Exception as e:
        print(f"Terjadi kesalahan saat mendownload video: {e}")

# Mengecek apakah argumen URL diberikan
if len(sys.argv) != 2:
    print("Penggunaan: Skrip ini dijalankan oleh URL opener.")
    print("Contoh: python ig_downloader.py <URL Instagram>")
    sys.exit(1)

# Ambil URL dari argumen pertama
url = sys.argv[1]

# Jalankan fungsi download
download_instagram_video(url)

# Tunggu input pengguna sebelum menutup skrip
input("Tekan Enter untuk keluar...")