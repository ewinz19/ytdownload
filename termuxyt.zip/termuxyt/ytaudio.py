#!/usr/bin/env python3
import sys
import os
import re
import shutil
from pytubefix import YouTube

def bersihkan_nama_file(nama):
    """Membersihkan nama file dari karakter tidak valid"""
    # Hapus karakter khusus yang bermasalah
    nama_bersih = re.sub(r'[\\/*?:"<>|]', '', nama)
    # Ganti spasi ganda dengan tunggal
    nama_bersih = re.sub(r'\s+', ' ', nama_bersih).strip()
    return nama_bersih

def Download(link):
    print("Download Started")
    print("Tunggu sampai selesai download audio...")
    
    try:
        # Inisialisasi YouTube
        yt = YouTube(link)
        audio_stream = yt.streams.filter(only_audio=True).first()
        
        if not audio_stream:
            print("Error: Video tidak memiliki audio stream")
            return

        # Siapkan folder tujuan
        folder_tujuan = "/data/data/com.termux/files/home/storage/downloads/AA-yt/audio"
        os.makedirs(folder_tujuan, exist_ok=True)

        # Dapatkan judul video dan bersihkan
        judul_video = bersihkan_nama_file(yt.title)
        nama_file = f"{judul_video}.mp3"
        path_tujuan = os.path.join(folder_tujuan, nama_file)

        # Download langsung ke format MP3
        print(f"Mendownload: {yt.title}")
        file_path = audio_stream.download(
            output_path=folder_tujuan,
            filename=nama_file,
            skip_existing=False
        )

        print("Download selesai dengan sukses!")
        print(f"File disimpan di: {path_tujuan}")

    except Exception as e:
        print(f"Terjadi kesalahan: {str(e)}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Penggunaan: {sys.argv[0]} <URL YouTube>")
        sys.exit(1)

    youtube_url = sys.argv[1]
    Download(youtube_url)