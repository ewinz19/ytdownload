#!/bin/bash

# GPS Coordinates Extractor Script with separate lat/long files

# Configuration
dir="/data/data/com.termux/files/home/"
OUTPUT_DIR="$dir/bin/fake/"
LAT_FILE="${OUTPUT_DIR}lat.txt"
LONG_FILE="${OUTPUT_DIR}long.txt"

# Create output directory if not exists
mkdir -p "$OUTPUT_DIR"

# Extract coordinates function
extract_coords() {
    local url="$1"
    [ -z "$url" ] && { echo "Error: No URL provided"; return 1; }
    
    # Get final URL after redirects
    local full_url=$(curl -Ls -o /dev/null -w "%{url_effective}" "$url" 2>/dev/null)
    [ -z "$full_url" ] && { echo "Error: Failed to resolve URL"; return 1; }

    # Try multiple patterns to extract coordinates
    local coords=$(echo "$full_url" | grep -Eo '!3d-?[0-9]+\.[0-9]+!4d-?[0-9]+\.[0-9]+' | sed -E 's/!3d([^!]+)!4d([^!]+)/\1 \2/')
    
    # Alternative patterns if first one fails
    [ -z "$coords" ] && coords=$(echo "$full_url" | grep -Eo '/@-?[0-9]+\.[0-9]+,-?[0-9]+\.[0-9]+' | cut -d@ -f2 | tr ',' ' ')
    [ -z "$coords" ] && coords=$(echo "$full_url" | grep -Eo '/place/-?[0-9]+\.[0-9]+,-?[0-9]+\.[0-9]+' | cut -d/ -f3 | tr ',' ' ')
    
    [ -z "$coords" ] && { echo "Error: No coordinates found in URL"; return 1; }
    
    echo "$coords"
}

# Main execution
if [ $# -eq 0 ]; then
    echo "Usage: $0 <google_maps_url>"
    exit 1
fi

COORDS=$(extract_coords "$1")
if [ $? -eq 0 ]; then
    # Split coordinates into latitude and longitude
    LAT=$(echo "$COORDS" | awk '{print $1}')
    LONG=$(echo "$COORDS" | awk '{print $2}')
    
    # Save to separate files
    echo "$LAT" > "$LAT_FILE"
    echo "$LONG" > "$LONG_FILE"
    
    echo "Coordinates saved:"
    echo "Latitude: $LAT (saved to $LAT_FILE)"
    echo "Longitude: $LONG (saved to $LONG_FILE)"
   
else
    echo "Failed to extract coordinates" >&2
    exit 1
fi

su -c "sh "$dir/bin/fake/fake.sh""

su -c "sh "$dir/bin/fake/cekdebug.sh""

read -p "exit enter :" exit
