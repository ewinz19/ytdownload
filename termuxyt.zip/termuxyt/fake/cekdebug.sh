#!/bin/bash

echo "=== Android Debug Status Checker ==="

# Check Developer Options
dev_status=$(settings get global development_settings_enabled 2>/dev/null || echo "0")
echo -e "\n[1] Developer Options: $([ "$dev_status" -eq 1 ] && echo "ENABLED" || echo "DISABLED")"

# Check USB Debugging
adb_status=$(settings get global adb_enabled 2>/dev/null || echo "0")
echo "[2] USB Debugging: $([ "$adb_status" -eq 1 ] && echo "ENABLED" || echo "DISABLED")"

# Check Mock Locations
mock_status=$(settings get secure mock_location 2>/dev/null || echo "0")
echo "[3] Mock Locations: $([ "$mock_status" -eq 1 ] && echo "ENABLED" || echo "DISABLED")"

# Check Mock Location App
echo -e "\n[4] Mock Location Apps:"
found=0
for pkg in $(cmd package list packages 2>/dev/null | cut -d: -f2); do
    result=$(appops get $pkg android:mock_location 2>/dev/null | grep -v 'No UID')
    if [[ "$result" == *allow* ]]; then
        echo "  - $pkg: ENABLED"
        found=1
    fi
done
[ "$found" -eq 0 ] && echo "  No apps have mock location permission"
