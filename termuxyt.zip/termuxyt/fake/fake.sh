#!/bin/bash
settings put secure location_mode 3

settings put global adb_enabled 0
settings put global development_settings_enabled 0
settings put secure mock_location 0

appops set com.lexa.fakegps android:mock_location allow




# Read coordinates from files
latt=$(cat /data/data/com.termux/files/home/bin/fake/lat.txt)
longg=$(cat /data/data/com.termux/files/home/bin/fake/long.txt)

# Verify coordinates exist
if [ -z "$latt" ] || [ -z "$longg" ]; then
    echo "Error: Could not read coordinates from files"
    exit 1
fi

# Send to Fake GPS app
am startservice -n com.lexa.fakegps/.FakeGPSService \
    -a com.lexa.fakegps.START \
    --es lat "$latt" \
    --es long "$longg"

# Verify service started
if [ $? -eq 0 ]; then
    echo "Successfully set location to:"
    echo "Latitude: $latt"
    echo "Longitude: $longg"
else
    echo "Failed to set location in Fake GPS"
    exit 1
fi


am start com.google.android.apps.maps/com.google.android.maps.MapsActivity
sleep 1
am start com.jeyluta.timestampcamerafree/com.example.PermissionActivity

sleep 5
am start com.jeyluta.timestampcamerafre
appops set com.lexa.fakegps android:mock_location deny



#
