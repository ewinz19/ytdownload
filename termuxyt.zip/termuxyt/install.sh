pkg install -y python3 
pkg install pip -y
pkg install sys -y
pkg install ffmpeg -y

pip install pytubefix
pip install yt_dlp

export HOME=/data/data/com.termux/files/home
termux-setup-storage -y

echo buat akses bin termux-url-opener

mkdir -p /data/data/com.termux/files/home/bin
mkdir -p /data/data/com.termux/files/home/bin/termuxyt
su -c "
echo buat folder AA-yt
mkdir -p /data/data/com.termux/files/home/storage/downloads/AA-yt
sleep 2
echo buat folder audio
mkdir -p /data/data/com.termux/files/home/storage/downloads/AA-yt/audio

sleep 2
echo buat folder mp3
mkdir -p /data/data/com.termux/files/home/storage/downloads/AA-yt/mp3

sleep 2
echo buat folder video
mkdir -p /data/data/com.termux/files/home/storage/downloads/AA-yt/video


mkdir -p /data/data/com.termux/files/home/storage/downloads/AA-ig/video

"
sleep 2
mv $HOME/termuxyt/termux-url-opener /data/data/com.termux/files/home/bin/
#pindah file python *.py
mv $HOME/termuxyt/*.py /data/data/com.termux/files/home/bin/termuxyt/

echo sukses
exit 0
