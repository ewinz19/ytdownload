#!/bin/bash

# Setup storage
termux-setup-storage
sleep 5  # Beri waktu untuk mengizinkan akses storage
cd $HOME
echo $HOME
sleep 3
# Install dependencies
pkg install -y python3 ffmpeg figlet

pkg install python
pkg install openssl
sleep 1
pip install -y pytubefix 
pip install -y yt_dlp
# Create necessary directories
mkdir -p ~/bin/termuxyt
mkdir -p ~/storage/downloads/AA-yt/audio
mkdir -p ~/storage/downloads/AA-yt/mp3
mkdir -p ~/storage/downloads/AA-yt/video
mkdir -p ~/storage/downloads/AA-ig/video

# Move files (assuming they exist in termuxyt directory)
if [ -f ~/termuxyt/termux-url-opener ]; then
    mv ~/termuxyt/termux-url-opener ~/bin/
fi
# Pastikan direktori tujuan ada
mkdir -p ~/bin/termuxyt
mkdir -p ~/bin/fake
# Pindahkan semua file .py (jika ada)
if ls ~/termuxyt/*.py 1> /dev/null 2>&1; then
    mv ~/termuxyt/*.py ~/bin/termuxyt/
    echo "Berhasil memindahkan file Python"
else
    echo "Tidak ada file Python yang ditemukan di ~/termuxyt/"
fi

#Pindahkan semua file .sh (jika ada)
if ls ~/termuxyt/fake/*.sh 1> /dev/null 2>&1; then
    mv ~/termuxyt/fake/*.sh ~/bin/fake/
    echo "Berhasil memindahkan file .sh"
else
    echo "Tidak ada file .sh yang ditemukan di ~/termuxyt/fake/"
fi



chmod -R 775 ~/bin/
chmod 775 ~/bin/termuxyt
chmod 664 ~/bin/termuxyt/*

chmod 775 ~/bin/termuxyt/fake
chmod 664 ~/bin/termuxyt/fake/*

cd
ls -la bin/termuxyt/*
echo "Installation successful!"
exit 0